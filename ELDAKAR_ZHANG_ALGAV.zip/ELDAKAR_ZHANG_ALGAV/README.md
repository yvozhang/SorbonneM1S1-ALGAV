# ALGAV

Pour tester :


- **echauffement.py** : décommenter la ligne 61
-  **arbre_decision_comp.py** : 
    - pour tester la fonction **cons_arb** : décommenter de la ligne 170 à 174
    - pour tester la fonction **luka** : décommenter de la ligne 178 à 183
    - pour tester la fonction **compression** : décommenter de la ligne 186 à 192
-  **arbre_ROBDD.py** : décommenter de la ligne 25 à 32 pour tester la fonction compression_bdd
-  **exprimentale.py** : décommenter à partir de la ligne 440 pour tester.

La totalité du projet ce trouve dans le fichier **projet_Algav.py**
NB : avant de passer à un autre ficher il faut les parties en commentaires soient en commentaires. 

Projet par : 
ELDAKAR Joumana /
ZHANG Zimeng 
